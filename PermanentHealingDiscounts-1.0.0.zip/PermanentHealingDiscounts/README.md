# PermanentHealingDiscounts

Standalone Paper plugin for Paper 26.2 / Java 25.

## Intended behavior

- Successful villager cures accumulate permanently.
- Cure discounts are villager-wide rather than player-specific.
- Repeated cures stack without the normal modern cure limit.
- Cure state persists with the villager through restarts and chunk unloads.
- No configuration, database, or external plugin dependency.

## Build

Use the Gradle Wrapper in your Codespace or a local Gradle installation with Java 25:

    ./gradlew build

The JAR is written to `build/libs/`.

## Note

The current source establishes persistent cure tracking. The trade-pricing layer will be implemented and tested against Paper 26.2 before release.
