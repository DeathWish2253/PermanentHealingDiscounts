package com.deathwish.permanenthealingdiscounts;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

public final class PermanentHealingDiscounts extends JavaPlugin {
    public static final int MAX_CURE_DISCOUNTS = 1_000_000;
    private NamespacedKey cureCountKey;

    @Override
    public void onEnable() {
        cureCountKey = new NamespacedKey(this, "cure_count");
        getServer().getPluginManager().registerEvents(new VillagerCureListener(this), this);
        getLogger().info("PermanentHealingDiscounts 1.0.0 enabled.");
    }

    public NamespacedKey getCureCountKey() {
        return cureCountKey;
    }
}
