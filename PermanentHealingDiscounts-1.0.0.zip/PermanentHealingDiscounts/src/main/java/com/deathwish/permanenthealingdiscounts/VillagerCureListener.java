package com.deathwish.permanenthealingdiscounts;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Villager;
import org.bukkit.entity.ZombieVillager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

/**
 * Persists the number of successful cures on the villager.
 *
 * The pricing layer is intentionally kept separate from cure detection so
 * the plugin can be tested and refined without coupling cure state to a
 * player's identity.
 */
public final class VillagerCureListener implements Listener {
    private final PermanentHealingDiscounts plugin;

    public VillagerCureListener(PermanentHealingDiscounts plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onZombieVillagerTransform(EntityTransformEvent event) {
        if (!(event.getEntity() instanceof ZombieVillager zombie)) {
            return;
        }
        if (event.getTransformReason() != EntityTransformEvent.TransformReason.CURED) {
            return;
        }
        if (!(event.getTransformedEntity() instanceof Villager villager)) {
            return;
        }

        int previous = getCureCount(zombie);
        int next = Math.min(PermanentHealingDiscounts.MAX_CURE_DISCOUNTS, previous + 1);
        setCureCount(villager, next);
    }

    private int getCureCount(Entity entity) {
        PersistentDataContainer pdc = entity.getPersistentDataContainer();
        Integer count = pdc.get(plugin.getCureCountKey(), PersistentDataType.INTEGER);
        return count == null ? 0 : Math.max(0, count);
    }

    private void setCureCount(Villager villager, int count) {
        villager.getPersistentDataContainer().set(
                plugin.getCureCountKey(),
                PersistentDataType.INTEGER,
                count
        );
    }
}
