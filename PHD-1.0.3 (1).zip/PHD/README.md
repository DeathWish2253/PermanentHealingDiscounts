# PermanentHealingDiscounts (PHD)

Standalone Paper plugin for Paper 26.2 / Java 25.

## Behavior

- Every successful zombie-villager cure adds one permanent cure discount to the villager.
- Cure discounts stack without an artificial cure limit.
- The discount is villager-wide: every player receives the same accumulated cure discount when they trade with that villager.
- Players who traded before a cure, players who have never traded with the villager, and players who join later all receive the accumulated discount.
- The discount persists through chunk unloads, restarts, and server shutdowns because the cure count is stored on the villager's PersistentDataContainer.
- Existing already-cured villagers are detected and migrated when first encountered. Vanilla's exact historical repeated-cure count cannot always be reconstructed, so the plugin uses the strongest cure reputation still stored on the villager as the migration baseline.
- Existing player reputation is never lowered.
- Normal villager demand remains intact.
- Normal trading reputation remains intact.
- Normal negative reputation remains intact.
- Hero of the Village remains intact.
- Vanilla minor-positive cure gossip is left alone, including its normal decay.
- No configuration, database, ProtocolLib, PlaceholderAPI, or other plugin dependency.

## Technical approach

Paper 26.2 exposes per-player villager reputation through `Villager#getReputation` / `setReputation`. PHD raises only `MAJOR_POSITIVE` to the villager's accumulated cure count multiplied by the vanilla +20-per-cure value. The other reputation categories are preserved unchanged.

The update is performed at `PlayerInteractEntityEvent` priority LOWEST, before the villager trading interface opens. This lazy synchronization means offline players and players who have never joined do not need to be enumerated or stored ahead of time.

## Build

Use Java 25 and Gradle:

    ./gradlew build

The JAR is written to `build/libs/PermanentHealingDiscounts-1.0.3.jar`.


## Debug log

PHD 1.0.3 writes a dedicated `phd-debug.log` inside the plugin's data folder. It records successful cures, existing-cure migration, and player discount application with timestamps, villager/player UUIDs, location, stored/inferred cure counts, and target major-positive reputation. This file is intended for troubleshooting and can be pasted into chat when diagnosing behavior.
