package com.deathwish.permanenthealingdiscounts;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

public final class PermanentHealingDiscounts extends JavaPlugin {
    public static final int MAJOR_POSITIVE_PER_CURE = 20;

    private NamespacedKey cureCountKey;
    private Path debugLog;

    @Override
    public void onEnable() {
        cureCountKey = new NamespacedKey(this, "cure_count");
        debugLog = getDataFolder().toPath().resolve("phd-debug.log");

        getServer().getPluginManager().registerEvents(new VillagerCureListener(this), this);
        getServer().getPluginManager().registerEvents(new VillagerDiscountListener(this), this);

        debug("=== PHD debug logging started: version 1.0.3 ===");
        getLogger().info("PermanentHealingDiscounts 1.0.3 enabled.");
    }

    public NamespacedKey getCureCountKey() {
        return cureCountKey;
    }

    public void debug(String message) {
        String line = "[" + OffsetDateTime.now(ZoneOffset.UTC) + "] " + message;
        try {
            Files.createDirectories(getDataFolder().toPath());
            Files.writeString(debugLog, line + System.lineSeparator(),
                    StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
        } catch (IOException ex) {
            getLogger().warning("Could not write phd-debug.log: " + ex.getMessage());
        }
    }
}
