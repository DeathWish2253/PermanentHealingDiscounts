package com.deathwish.permanenthealingdiscounts;

import com.destroystokyo.paper.entity.villager.Reputation;
import com.destroystokyo.paper.entity.villager.ReputationType;
import org.bukkit.Bukkit;
import org.bukkit.entity.Villager;
import org.bukkit.entity.ZombieVillager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

/** Records successful zombie-villager cures on the resulting villager. */
public final class VillagerCureListener implements Listener {
    private final PermanentHealingDiscounts plugin;

    public VillagerCureListener(PermanentHealingDiscounts plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onZombieVillagerTransform(EntityTransformEvent event) {
        if (!(event.getEntity() instanceof ZombieVillager)) {
            return;
        }
        if (event.getTransformReason() != EntityTransformEvent.TransformReason.CURED) {
            return;
        }
        if (!(event.getTransformedEntity() instanceof Villager villager)) {
            return;
        }

        // Let vanilla finish creating/applying the cured villager first.
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!villager.isValid()) {
                plugin.debug("CURE_ABORTED reason=transformed_villager_invalid");
                return;
            }

            int stored = getCureCount(villager);
            int inferred = 0;
            int current = stored;
            if (current <= 0) {
                inferred = inferExistingCures(villager);
                current = inferred;
            }

            int after = Math.min(Integer.MAX_VALUE, current + 1);
            setCureCount(villager, after);

            plugin.debug(String.format(
                    "CURE_SUCCESS villager=%s world=%s x=%.2f y=%.2f z=%.2f storedBefore=%d inferredExisting=%d cureCountBefore=%d cureCountAfter=%d targetMajor=%d",
                    villager.getUniqueId(),
                    villager.getWorld().getName(),
                    villager.getX(), villager.getY(), villager.getZ(),
                    stored, inferred, current, after,
                    (long) after * PermanentHealingDiscounts.MAJOR_POSITIVE_PER_CURE
            ));
        });
    }

    static int getCureCount(PermanentHealingDiscounts plugin, Villager villager) {
        Integer value = villager.getPersistentDataContainer().get(
                plugin.getCureCountKey(), PersistentDataType.INTEGER
        );
        return value == null ? 0 : Math.max(0, value);
    }

    private int getCureCount(Villager villager) {
        return getCureCount(plugin, villager);
    }

    static void setCureCount(PermanentHealingDiscounts plugin, Villager villager, int count) {
        int safe = Math.max(0, count);
        villager.getPersistentDataContainer().set(
                plugin.getCureCountKey(),
                PersistentDataType.INTEGER,
                safe
        );
    }

    private void setCureCount(Villager villager, int count) {
        setCureCount(plugin, villager, count);
    }

    /**
     * Migrates an already-cured villager when PHD has never seen it before.
     * Vanilla stores cure reputation per player, so the exact number of old
     * repeated cures cannot always be reconstructed. The highest stored
     * major-positive value gives the number of known cure increments.
     */
    static int inferExistingCures(Villager villager) {
        int inferred = 0;
        for (Reputation reputation : villager.getReputations().values()) {
            int major = reputation.getReputation(ReputationType.MAJOR_POSITIVE);
            if (major > 0) {
                inferred = Math.max(
                        inferred,
                        (major + PermanentHealingDiscounts.MAJOR_POSITIVE_PER_CURE - 1)
                                / PermanentHealingDiscounts.MAJOR_POSITIVE_PER_CURE
                );
            }

            // A minor-positive cure entry is also evidence that this villager
            // has been cured, even if the permanent major entry is unavailable.
            if (reputation.getReputation(ReputationType.MINOR_POSITIVE) > 0) {
                inferred = Math.max(inferred, 1);
            }
        }
        return inferred;
    }
}
