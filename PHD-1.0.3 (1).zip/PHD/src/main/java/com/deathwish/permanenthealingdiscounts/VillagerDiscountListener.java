package com.deathwish.permanenthealingdiscounts;

import com.destroystokyo.paper.entity.villager.Reputation;
import com.destroystokyo.paper.entity.villager.ReputationType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;

/** Applies the villager's permanent cure discount to each player at trade time. */
public final class VillagerDiscountListener implements Listener {
    private final PermanentHealingDiscounts plugin;

    public VillagerDiscountListener(PermanentHealingDiscounts plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onVillagerInteract(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Villager villager)) {
            return;
        }

        int cures = VillagerCureListener.getCureCount(plugin, villager);
        if (cures <= 0) {
            cures = VillagerCureListener.inferExistingCures(villager);
            if (cures > 0) {
                VillagerCureListener.setCureCount(plugin, villager, cures);
                plugin.debug(String.format(
                        "MIGRATION villager=%s world=%s x=%.2f y=%.2f z=%.2f inferredCureCount=%d targetMajor=%d",
                        villager.getUniqueId(), villager.getWorld().getName(),
                        villager.getX(), villager.getY(), villager.getZ(),
                        cures, (long) cures * PermanentHealingDiscounts.MAJOR_POSITIVE_PER_CURE
                ));
            }
        }

        if (cures <= 0) {
            return;
        }

        Player player = event.getPlayer();
        Reputation reputation = villager.getReputation(player.getUniqueId());

        int desiredMajor = safeMultiply(cures, PermanentHealingDiscounts.MAJOR_POSITIVE_PER_CURE);
        int currentMajor = reputation.getReputation(ReputationType.MAJOR_POSITIVE);

        // Never overwrite or lower a player's existing major-positive gossip.
        // Trading, negative reputation, Hero of the Village, and minor-positive
        // reputation remain untouched.
        if (currentMajor >= desiredMajor) {
            return;
        }

        reputation.setReputation(ReputationType.MAJOR_POSITIVE, desiredMajor);
        villager.setReputation(player.getUniqueId(), reputation);

        plugin.debug(String.format(
                "DISCOUNT_APPLIED villager=%s player=%s cures=%d currentMajor=%d desiredMajor=%d world=%s x=%.2f y=%.2f z=%.2f",
                villager.getUniqueId(), player.getUniqueId(), cures, currentMajor, desiredMajor,
                villager.getWorld().getName(), villager.getX(), villager.getY(), villager.getZ()
        ));
    }

    private static int safeMultiply(int left, int right) {
        long value = (long) left * right;
        return value >= Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) value;
    }
}
